package com.example.dustinadams.listwithjson;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import static com.example.dustinadams.listwithjson.R.id.dateDisplay;
import static com.example.dustinadams.listwithjson.R.id.deleteButton;
import static com.example.dustinadams.listwithjson.R.id.timeDisplay;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DetailActivity extends AppCompatActivity {

    public JSONObject jo = null;
    public JSONArray ja = null;

    @SuppressLint("ResourceType")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);



        Button deleteButton = (Button) findViewById(R.id.deleteButton);

        final Intent i = getIntent();
        String title = i.getStringExtra("first");
        String description = i.getStringExtra("second");
        String date = i.getStringExtra("third");
        String time = i.getStringExtra("fourth");
        final int position = i.getIntExtra("fifth", 0);
        String GPS = i.getStringExtra("sixth");


        TextView t = (TextView)findViewById(R.id.textView3);
        TextView d = (TextView)findViewById(R.id.textView4);
        TextView da = (TextView)findViewById(R.id.dateDisplay);
        TextView ti = (TextView)findViewById(R.id.timeDisplay);
        TextView G = (TextView)findViewById(R.id.GPSdisplay);


        t.setText(title);
        d.setText(description);
        da.setText(date);
        ti.setText(time);
        G.setText(GPS);

        //final EditText first = findViewById(R.id.editText);
        //final EditText second = findViewById(R.id.editText2);
        final Date now = new Date();
        final Date nowT = new Date();
        final SimpleDateFormat dateFormatter = new SimpleDateFormat("MM-dd-yyyy");
        final SimpleDateFormat dateFormatterT = new SimpleDateFormat("hh:mm:ss a");

        try{
            File f = new File(getFilesDir(), "file.ser");
            FileInputStream fi = new FileInputStream(f);
            ObjectInputStream o = new ObjectInputStream(fi);
            // Notice here that we are de-serializing a String object (instead of
            // a JSONObject object) and passing the String to the JSONObject’s
            // constructor. That’s because String is serializable and
            // JSONObject is not. To convert a JSONObject back to a String, simply
            // call the JSONObject’s toString method.
            String j = null;
            try{
                j = (String) o.readObject();
            }
            catch(ClassNotFoundException c){
                c.printStackTrace();
            }
            try {
                jo = new JSONObject(j);
                ja = jo.getJSONArray("data");
            }
            catch(JSONException e){
                e.printStackTrace();
            }
        }
        catch(IOException e){
            // Here, initialize a new JSONObject
            jo = new JSONObject();
            ja = new JSONArray();
            try{
                jo.put("data", ja);
            }
            catch(JSONException j){
                j.printStackTrace();
            }
        }




        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {




                ja.remove(position);

                // write the file
                try{
                    File f = new File(getFilesDir(), "file.ser");
                    FileOutputStream fo = new FileOutputStream(f);
                    ObjectOutputStream o = new ObjectOutputStream(fo);
                    String j = jo.toString();
                    o.writeObject(j);
                    o.close();
                    fo.close();
                }
                catch(IOException e){

                }
                openDeleteActivity();
            }
        });









    }

    public void openDeleteActivity()
    {
        Intent mainIntent = new Intent (this, MainActivity.class);
        startActivity(mainIntent);
    }
}
