package com.example.dustinadams.listwithjson;

public class ListData {
    public String firstText;

}
