package com.example.assignment1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import java.lang.Math;
import java.text.DecimalFormat;
import java.util.IllegalFormatPrecisionException;

/*
Vishal Damojipurapu
Assignment1
4/18/20

https://www.youtube.com/watch?v=kp0DefpSMYw
-watched the tutorial above for assistance on how to get started
 */

public class MainActivity extends AppCompatActivity {

    float answer;
    float input;

    TextView n1, result1,n2,result2,n3,result3,n4,result4;
    EditText exponent1,exponent2,exponent3,exponent4;
    Button button1,button2,button3,button4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



            result1 = findViewById(R.id.result1);
            n1 = findViewById(R.id.n1);
            exponent1 = findViewById(R.id.exponent1);
            button1 = findViewById(R.id.button1);

            button1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    try {
                        input = Float.parseFloat(exponent1.getText().toString());
                        answer = (float) Math.pow(2, input);
                        answer = Math.round(answer * 100);
                        answer = answer / 100;
                        result1.setText(String.valueOf(String.format("%,.2f", answer)));
                    }

                    catch(NumberFormatException a)
                    {
                        result1.setText("error");
                    }
                }
            });





        result2 = findViewById(R.id.result2);
        n2 = findViewById(R.id.n2);
        exponent2 = findViewById(R.id.exponent2);
        button2 = findViewById(R.id.button2);

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    input = Float.parseFloat(exponent2.getText().toString());
                    answer = (float) Math.pow(3, input);
                    answer = Math.round(answer * 100);
                    answer = answer / 100;
                    //DecimalFormat formatter = new DecimalFormat("#0.00");
                    //answer = (float) formatter.format(answer);
                    //result2.setText(String.valueOf(answer));
                    result2.setText(String.valueOf(String.format("%,.2f", answer)));
                }

                catch(NumberFormatException a)
                {
                    result2.setText("error");
                }
            }
        });


        result3 = findViewById(R.id.result3);
        n3 = findViewById(R.id.n3);
        exponent3 = findViewById(R.id.exponent3);
        button3 = findViewById(R.id.button3);

        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    input = Float.parseFloat(exponent3.getText().toString());
                    answer = (float) Math.pow(4, input);
                    answer = Math.round(answer * 100);
                    answer = answer / 100;
                    result3.setText(String.valueOf(String.format("%,.2f", answer)));
                }

                catch(NumberFormatException a){
                    result3.setText("error");
                }
            }
        });

        result4 = findViewById(R.id.result4);
        n4 = findViewById(R.id.n4);
        exponent4 = findViewById(R.id.exponent4);
        button4 = findViewById(R.id.button4);

        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    input = Float.parseFloat(exponent4.getText().toString());
                    answer = (float) Math.pow(5, input);
                    answer = Math.round(answer * 100);
                    answer = answer / 100;
                    result4.setText(String.valueOf(String.format("%,.2f", answer)));
                }

                catch(NumberFormatException a)
                {
                    result4.setText("error");
                }
            }
        });

    }
}
